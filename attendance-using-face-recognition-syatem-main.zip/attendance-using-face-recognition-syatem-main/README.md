# attendance-using-face-recognition-syatem
This Attendance System uses face recognition to automate and streamline attendance tracking. It captures and identifies faces in real-time, marking attendance accurately. By leveraging machine learning, it ensures secure and error-free record management, making it ideal for institutions to replace manual or card-based methods.
